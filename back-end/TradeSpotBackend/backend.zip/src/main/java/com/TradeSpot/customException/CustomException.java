package com.TradeSpot.customException;

public class CustomException extends  RuntimeException{

    public CustomException(String message){
        super(message);
    }
}
