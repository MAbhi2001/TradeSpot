
package com.TradeSpot.entities;



public enum Roles {

    USER, ADMIN;
}
